import styled from "styled-components";

export const HomePageContainer = styled.div`
  color: white;
`;
